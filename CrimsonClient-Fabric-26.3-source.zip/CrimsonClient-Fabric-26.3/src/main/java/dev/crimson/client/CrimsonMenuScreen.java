package dev.crimson.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class CrimsonMenuScreen extends Screen {
    private boolean cpsHud;
    private boolean armorHud;
    private boolean coordinatesHud;
    private boolean keystrokesHud;

    public CrimsonMenuScreen() {
        super(Component.literal("CRIMSON CLIENT"));
    }

    @Override
    protected void init() {
        int panelWidth = 230;
        int left = (this.width - panelWidth) / 2;
        int top = Math.max(30, (this.height - 190) / 2);
        int buttonWidth = 190;
        int buttonLeft = left + 20;

        addRenderableWidget(toggleButton(buttonLeft, top + 42, buttonWidth, "CPS HUD", 0));
        addRenderableWidget(toggleButton(buttonLeft, top + 72, buttonWidth, "ARMOR HUD", 1));
        addRenderableWidget(toggleButton(buttonLeft, top + 102, buttonWidth, "COORDINATES", 2));
        addRenderableWidget(toggleButton(buttonLeft, top + 132, buttonWidth, "KEYSTROKES", 3));
        addRenderableWidget(Button.builder(Component.literal("CERRAR"), b -> onClose())
                .bounds(buttonLeft, top + 162, buttonWidth, 20).build());
    }

    private Button toggleButton(int x, int y, int width, String label, int id) {
        return Button.builder(toggleText(label, id), button -> {
            switch (id) {
                case 0 -> cpsHud = !cpsHud;
                case 1 -> armorHud = !armorHud;
                case 2 -> coordinatesHud = !coordinatesHud;
                case 3 -> keystrokesHud = !keystrokesHud;
            }
            button.setMessage(toggleText(label, id));
        }).bounds(x, y, width, 20).build();
    }

    private Component toggleText(String label, int id) {
        boolean enabled = switch (id) {
            case 0 -> cpsHud;
            case 1 -> armorHud;
            case 2 -> coordinatesHud;
            case 3 -> keystrokesHud;
            default -> false;
        };
        return Component.literal(label + (enabled ? "  [ON]" : "  [OFF]"));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        this.renderBackground(graphics, mouseX, mouseY, delta);

        int panelWidth = 230;
        int panelHeight = 205;
        int left = (this.width - panelWidth) / 2;
        int top = Math.max(25, (this.height - panelHeight) / 2);

        graphics.fill(left, top, left + panelWidth, top + panelHeight, 0xF0141414);
        graphics.fill(left, top, left + panelWidth, top + 4, 0xFFFF2525);
        graphics.fill(left, top + 4, left + 3, top + panelHeight, 0xFFFF2525);
        graphics.fill(left + panelWidth - 3, top + 4, left + panelWidth, top + panelHeight, 0xFFFF2525);
        graphics.fill(left, top + panelHeight - 3, left + panelWidth, top + panelHeight, 0xFFFF2525);

        graphics.drawCenteredString(this.font, "CRIMSON CLIENT", this.width / 2, top + 14, 0xFFFF3030);
        graphics.drawCenteredString(this.font, "PvP TRAINING HUD", this.width / 2, top + 29, 0xFFFFFFFF);

        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
