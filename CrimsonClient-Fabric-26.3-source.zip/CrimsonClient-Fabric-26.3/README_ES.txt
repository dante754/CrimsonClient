CRIMSON CLIENT — PROYECTO FUENTE
Minecraft Java 26.3 / Fabric / cliente

IMPORTANTE:
- Este ZIP contiene el PROYECTO FUENTE, todavía no un .jar compilado.
- La pantalla inicial permite abrir un menú con Right Shift y activar/desactivar
  cuatro interruptores de interfaz. Los módulos HUD son marcadores de interfaz:
  todavía no muestran CPS, armadura, coordenadas ni teclas en pantalla.
- No incluye funciones para hacer trampa, automatizar ataques ni obtener ventajas
  injustas en servidores.
- La configuración está basada en las referencias oficiales de Fabric para 26.3:
  Java 25, Fabric Loader 0.19.5, Fabric API 0.163.0+26.3 y Loom 1.18-SNAPSHOT.
- Tu perfil de Pojav muestra loader 0.20.1; habrá que comprobar que esa instalación
  carga correctamente el mod. No cambies tu perfil todavía.

Para compilar hace falta Gradle y Java 25. El entorno donde se preparó este ZIP
no tiene Java 25, así que no se afirma que el .jar esté compilado o probado.

Controles:
- Right Shift: abrir el menú.
- CERRAR: cerrar el menú.
